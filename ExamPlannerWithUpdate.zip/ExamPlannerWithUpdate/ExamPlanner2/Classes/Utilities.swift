//
//  Utilities.swift
//  ExamPlanner2
//
//  Created by 19shrinandhanp on 7/7/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit

class Utilities: NSObject
{
    class func dynamicFontSizeForIphone(fontSize : CGFloat) -> CGFloat
    {
        var current_Size : CGFloat = 0.0
        current_Size = (UIScreen.main.bounds.width/320)
        let FinalSize : CGFloat = fontSize * current_Size
        return FinalSize
        
    }}
