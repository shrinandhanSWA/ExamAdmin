//
//  Constants.swift
//  ExamSeatingPlanner
//
//  Created by 19shrinandhanp on 6/26/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import Foundation

     let keyName = "name"
     let keySubject = "subject"
     let keyComponent = "component"
     let keyLevel = "level"
     let keyDate = "date"
     let keySpecial = "special_requirements"


let custFont_Roboto_Regular = "Roboto-Regular"
let custFont_Roboto_Bold = "Roboto-Bold"
let custFont_Robot_Medium = "Roboto-Medium"
