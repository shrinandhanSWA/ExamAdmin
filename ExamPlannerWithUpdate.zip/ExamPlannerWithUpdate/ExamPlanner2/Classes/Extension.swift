//
//  Extension.swift
//  ExamPlanner2
//
//  Created by 19shrinandhanp on 7/7/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit
import Foundation

extension UIFont {
    class func getFont(custFontName strFontName:String, ofSize size: CGFloat) -> UIFont {
        return UIFont(name: strFontName, size: Utilities.dynamicFontSizeForIphone(fontSize: size))!
    }
}
