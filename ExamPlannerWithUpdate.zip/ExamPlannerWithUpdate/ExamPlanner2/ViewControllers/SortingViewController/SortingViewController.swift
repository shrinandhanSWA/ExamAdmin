//
//  SortingViewController.swift
//  ExamPlanner2
//
//  Created by 19shrinandhanp on 8/5/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit
let APP_DELEGATE = UIApplication.shared.delegate as! AppDelegate

class SortingViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource
{

    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var btnManualSort: UIButton!
    var dataArray = NSMutableArray()
    var loadDataArray = NSMutableArray()
    fileprivate var longPressGesture: UILongPressGestureRecognizer!
    @IBOutlet weak var clnView: UICollectionView!
    @IBOutlet weak var btnSubjectSorting: UIButton!
    var manualSearch : Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()

        clnView.dataSource = self
        clnView.delegate = self
        // clnView.register(NSClassFromString("examCell"),forCellWithReuseIdentifier:"examCell");
        clnView.register(UINib(nibName: "examCell", bundle: nil), forCellWithReuseIdentifier: "examCell")
        
//         self.dummydata()
//        clnView.reloadData()
    
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
        clnView.addGestureRecognizer(longPressGesture)
        
        SVProgressHUD.show()
        self.APIManager()
        
        self.btnSubjectSorting.addTarget(self, action: #selector(onClickSorting), for: .touchUpInside)
         self.btnManualSort.addTarget(self, action: #selector(onClickManualSearch), for: .touchUpInside)
        self.btnSave.addTarget(self, action: #selector(onClickSave), for: .touchUpInside)
        
        self.btnSubjectSorting.backgroundColor = UIColor.brown
        self.btnSubjectSorting.setTitle("Sort", for: .normal)
        self.btnSubjectSorting.setTitleColor(UIColor.white, for: .normal)
        
        self.btnManualSort.backgroundColor = UIColor.white
        self.btnManualSort.setTitle("Manual Sorting", for: .normal)
        self.btnManualSort.setTitleColor(UIColor.blue, for: .normal)
        
    //    self.onClickSorting()
        
    }
    @objc func onClickSave()
    {
        APP_DELEGATE.saveDataArray = self.dataArray
        
        NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: nil)
        
        self.onClickBack()
    }
    
    @objc func onClickSorting(){
        
//        btnManualSort.backgroundColor = UIColor.white
//        btnSubjectSorting.backgroundColor = UIColor.lightGray
        
        self.btnSubjectSorting.backgroundColor = UIColor.brown
        self.btnSubjectSorting.setTitle("Automatic Sorting", for: .normal)
        self.btnSubjectSorting.setTitleColor(UIColor.white, for: .normal)
        
        self.btnManualSort.backgroundColor = UIColor.init(forColorString: "d9d9d9")
        self.btnManualSort.setTitle("Manual Sorting", for: .normal)
        self.btnManualSort.setTitleColor(UIColor.blue, for: .normal)
        
         manualSearch = false
        
        
        let firstNameSortDescriptor = NSSortDescriptor(key: "subject", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))
        let sortedByFirstName : NSArray = self.dataArray.sortedArray(using: [firstNameSortDescriptor]) as NSArray
        
        let secondSortonLevel = NSSortDescriptor(key: "level", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))
        let sorttedByLevel : NSArray = sortedByFirstName.sortedArray(using: [secondSortonLevel]) as NSArray
        
        let dictSort = sorttedByLevel.firstObject as! NSDictionary
        let strSubject :String = String(format: "%@",dictSort.object(forKey:keySubject ) as! CVarArg)
        var isSameSubject : Bool = false
        for i in sorttedByLevel
        {
            let sortdict = i as! NSDictionary
            let strCurrentSubject :String = String(format: "%@",sortdict.object(forKey:keySubject ) as! CVarArg)
            if strCurrentSubject.caseInsensitiveCompare(strSubject) == .orderedSame
            {
                isSameSubject = true
            }else{
                isSameSubject = false
            }
            
        }
        // sort By Subject level
        
        self.dataArray.removeAllObjects()
        
        if isSameSubject == true {
            
            self.dataArray.addObjects(from: sorttedByLevel as! [Any])
        }
        else
        {
        
        let newDataArray = NSMutableArray()
        newDataArray.addObjects(from: sorttedByLevel as! [Any])
        
        for  i in 0..<newDataArray.count
        {
            let dictData = newDataArray.object(at: i) as! NSDictionary
            
            if self.dataArray .contains(dictData)
            {
                
            }else
            {
                if i == 0
                {
                    self.dataArray.add(dictData)
                }else
                {
                    
                    let dictDataLast = self.dataArray.lastObject as! NSDictionary
                    let strSubjectNameLast  = dictDataLast.object(forKey: keySubject) as! String
                    let strSubjectName  = dictData.object(forKey: keySubject) as! String
                 
                    if strSubjectName != strSubjectNameLast
                    {
                        self.dataArray.add(dictData)
                    }
                }
            }
        }
        
        let pendingDatacount : Int = newDataArray.count - self.dataArray.count
        
        for i in 0..<pendingDatacount
       {
        if self.dataArray.count  != newDataArray.count
        {
            self.checkData(newDataArray: newDataArray)
        }
            
        }
    }
        
        self.clnView.reloadData()
       
     
    }
    func checkData(newDataArray : NSMutableArray)
    {
        
       
            for  i in 0..<newDataArray.count
            {
                let dictData = newDataArray.object(at: i) as! NSDictionary
                
                if self.dataArray .contains(dictData)
                {
                    
                }else
                {
                    if i == 0
                    {
                        self.dataArray.add(dictData)
                    }else
                    {
                        
                        let dictDataLast = self.dataArray.lastObject as! NSDictionary
                        let strSubjectNameLast  = dictDataLast.object(forKey: keySubject) as! String
                        let strSubjectName  = dictData.object(forKey: keySubject) as! String
                        
                        if strSubjectName != strSubjectNameLast
                        {
                            self.dataArray.add(dictData)
                        }
                    }
                }
                
            }
        
    }
    
    func dummydata() {
        
        
        var dictData = NSMutableDictionary()
        
        dictData.setValue("Nandhu", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Juan", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("SL", forKey:keyLevel)
        dictData.setValue("25/06/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
        dictData = NSMutableDictionary()
        dictData.setValue("Dino", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Aimee", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 2", forKey:keyComponent)
        dictData.setValue("SL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("LAPTOP", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Trina", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
        dictData = NSMutableDictionary()
        dictData.setValue("Trina123", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "Details"
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = UIColor.init(forColorString:"0096FF")
        self.navigationController?.navigationBar.isOpaque = false
        self.navigationController?.navigationBar.isTranslucent = false
    
        
        let btnback =  UIBarButtonItem(image:UIImage.init(named: "back"), style:  .plain, target: self, action: #selector(onClickBack))
        self.navigationItem.leftBarButtonItem = btnback
        
    }
    
    @objc func onClickBack()
    {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func handleLongGesture(gesture: UILongPressGestureRecognizer) {
        switch(gesture.state) {
            
        case .began:
            guard let selectedIndexPath = clnView.indexPathForItem(at: gesture.location(in: clnView)) else {
                break
            }
            clnView.beginInteractiveMovementForItem(at: selectedIndexPath)
        case .changed:
            clnView.updateInteractiveMovementTargetPosition(gesture.location(in: gesture.view!))
        case .ended:
            clnView.endInteractiveMovement()
        default:
            clnView.cancelInteractiveMovement()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "examCell", for: indexPath) as! examCell
        cell.backgroundColor = UIColor.lightGray
        cell.viewCln.backgroundColor = UIColor.init(forColorString:"0096FF")
        let dictData : NSDictionary = dataArray[indexPath.item] as! NSDictionary
        
        cell.lblName.text = dictData.object(forKey: keyName) as? String
        cell.lblSubject.text = dictData.object(forKey: keySubject) as? String
        
        
        cell.lblName.font = UIFont.getFont(custFontName: custFont_Robot_Medium
            , ofSize: 13)
        cell.lblSubject.font = UIFont.getFont(custFontName: custFont_Robot_Medium
            , ofSize: 13)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let dictData : NSMutableDictionary = NSMutableDictionary.init(dictionary: dataArray[indexPath.item] as! NSDictionary)
        // let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "StudentDetailsViewController") as! StudentDetailsViewController
        vc.dictStudentData = dictData
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return manualSearch
    } //http://localhost/api/product/read.php//
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        print("Starting Index: \(sourceIndexPath.item)")
        print("Ending Index: \(destinationIndexPath.item)")
        
        let dictData : NSDictionary = dataArray[sourceIndexPath.item] as! NSDictionary
        let dictDataDestination : NSDictionary = dataArray[destinationIndexPath.item] as! NSDictionary
        
        dataArray.replaceObject(at: destinationIndexPath.item, with: dictData)
        dataArray.replaceObject(at: sourceIndexPath.item, with: dictDataDestination)
        
        clnView.reloadData()
    }//
   
    
    @objc func onClickManualSearch()
    {
        self.btnSubjectSorting.backgroundColor = UIColor.init(forColorString: "d9d9d9")
        self.btnSubjectSorting.setTitle("Automatic Sorting", for: .normal)
        self.btnSubjectSorting.setTitleColor(UIColor.blue, for: .normal)
        
        self.btnManualSort.backgroundColor = UIColor.brown
        self.btnManualSort.setTitle("Manual Sorting", for: .normal)
        self.btnManualSort.setTitleColor(UIColor.white, for: .normal)
//        btnSubjectSorting.backgroundColor = UIColor.white
//        btnManualSort.backgroundColor = UIColor.lightGray
      manualSearch = true
        self.dataArray.removeAllObjects()
        self.dataArray.addObjects(from: loadDataArray as! [Any])
        self.clnView.reloadData()
    }
    
    func  APIManager()
    {
        self.dataArray.removeAllObjects()
        
        if GVUserDefaults.standard()?.userId != nil
        {
            let strUserId : String = GVUserDefaults.standard()?.userId! as String? ?? ""
            
            let urlString  : String = "http://php3.shaligraminfotech.com/esp/product/read.php?q=\(strUserId)"
        
        guard let url = URL(string: urlString) else {
            print("Error: cannot create URL")
            return
        }
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /todos/1")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                }
                return
            }
            // parse the result as JSON, since that's what the API provides
            do {
                guard let todo = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? NSDictionary else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The todo is: " + todo.description)
                
                let dictDataArray =  todo.object(forKey: "records") as? NSArray
                
                self.dataArray.addObjects(from: dictDataArray as! [Any])
                self.loadDataArray.addObjects(from: dictDataArray as! [Any])
                
                DispatchQueue.main.async {
                    self.clnView.reloadData()
                    SVProgressHUD.dismiss()
                    self.onClickSorting()
                }
                
                
            } catch  {
                print("error trying to convert data to JSON")
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                }
                return
            }
        }
        
        task.resume()
        
        }
    }

}
extension SortingViewController: UICollectionViewDelegateFlowLayout {
    
    internal func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellsAcross: CGFloat = CGFloat(3)
        var widthRemainingForCellContent = collectionView.bounds.width
        if let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout {
            let borderSize: CGFloat = flowLayout.sectionInset.left + flowLayout.sectionInset.right
            widthRemainingForCellContent -= borderSize + ((cellsAcross - 1) * flowLayout.minimumInteritemSpacing)
        }
        let cellWidth = widthRemainingForCellContent / cellsAcross
        return CGSize(width: cellWidth, height: cellWidth)

}
    
    internal func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.2) {
            if let cell = collectionView.cellForItem(at: indexPath) as? examCell {
                cell.viewCln.transform = .init(scaleX: 0.70, y: 0.70)
                cell.contentView.backgroundColor = UIColor.lightGray
            }
        }
    }
    
    internal func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.2) {
            if let cell = collectionView.cellForItem(at: indexPath) as? examCell {
                cell.viewCln.transform = .identity
                cell.contentView.backgroundColor = .white
            }
        }
    }
    
}
