//
//  StudentDetailsViewController.swift
//  ExamPlanner2
//
//  Created by 19shrinandhanp on 7/4/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit

class StudentDetailsViewController: UIViewController
{
    
    var dictStudentData : NSMutableDictionary!
    
    @IBOutlet weak var txtStudentName: ACFloatingTextField!
    
    @IBOutlet weak var txtSubject: ACFloatingTextField!
    
    @IBOutlet weak var txtComponent: ACFloatingTextField!
    
    @IBOutlet weak var txtLevel: ACFloatingTextField!
    
    @IBOutlet weak var txtDate: IQDropDownTextField!
    
    @IBOutlet weak var txtSpecial: ACFloatingTextField!
    @IBOutlet weak var btnEditing: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.fontAndColorSetup()
        // Do any additional setup after loading the view.
        
        if dictStudentData != nil
        {
            txtStudentName.text = dictStudentData.object(forKey: keyName) as? String
            txtSubject.text = dictStudentData.object(forKey: keySubject) as? String
            txtComponent.text = dictStudentData.object(forKey: keyComponent) as? String
            txtLevel.text = dictStudentData.object(forKey: keyLevel) as? String
            txtDate.selectedItem = dictStudentData.object(forKey: keyDate) as? String
            
            if let strSpecial = dictStudentData.object(forKey: keySpecial) as? String
            {
                txtSpecial.text = strSpecial
            }
        }
        
      
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "Student Details"
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = UIColor.init(forColorString:"0096FF")
        self.navigationController?.navigationBar.isOpaque = false
        self.navigationController?.navigationBar.isTranslucent = false
        
    
        let btnback =  UIBarButtonItem(image:UIImage.init(named: "back"), style:  .plain, target: self, action: #selector(onClickBack))
        self.navigationItem.leftBarButtonItem = btnback

    }
    
    @objc func onClickBack()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func fontAndColorSetup()
    {
        txtStudentName.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        txtSubject.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        txtComponent.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        txtLevel.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        txtDate.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        txtSpecial.font = UIFont.getFont(custFontName: custFont_Roboto_Regular, ofSize: 15)
        
        btnEditing.titleLabel?.font = UIFont.getFont(custFontName: custFont_Roboto_Bold, ofSize: 18)
        
        txtDate.isOptionalDropDown = true
 txtDate.dropDownMode = .datePicker
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
    
        txtDate.dateFormatter = formatter
    }
}
