//
//  HowtoUploadCsvViewController.swift
//  ExamPlanner2
//
//  Created by HITESH BALDANIYA on 19/10/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit

class HowtoUploadCsvViewController: UIViewController {

    @IBOutlet weak var btnUploadCSV: UIButton!
    @IBOutlet weak var btnCheckCSv: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnCheckCSv.addTarget(self, action: #selector(onClickCSVCheck), for: .touchUpInside)
        self.btnUploadCSV.addTarget(self, action: #selector(onClickUploadCSV), for: .touchUpInside)
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "How to Upload"
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = UIColor.init(forColorString:"0096FF")
        self.navigationController?.navigationBar.isOpaque = false
        self.navigationController?.navigationBar.isTranslucent = false
        
        let btnback =  UIBarButtonItem(image:UIImage.init(named: "back"), style:  .plain, target: self, action: #selector(onClickBack))
        self.navigationItem.leftBarButtonItem = btnback
        
    }
    
    @objc func onClickBack()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func onClickUploadCSV()
    {
        if GVUserDefaults.standard()?.userId != nil
        {
            let strUserId : String = GVUserDefaults.standard()?.userId! as String? ?? ""
            
        guard let url = URL(string: "http://php3.shaligraminfotech.com/esp/index.php?q=\(strUserId)") else {
            return //be safe
        }
        
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
        }
        }
    
    @objc func onClickCSVCheck()
    {
        let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "CheckCSVViewController") as! CheckCSVViewController
        let navigationVC = UINavigationController(rootViewController: homeViewController)
        self.present(navigationVC, animated: true, completion: nil)
    }
}
