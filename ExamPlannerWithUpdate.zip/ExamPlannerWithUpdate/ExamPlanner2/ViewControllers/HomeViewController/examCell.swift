//
//  examCell.swift
//  ExamSeatingPlanner
//
//  Created by 19shrinandhanp on 6/26/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit

class examCell: UICollectionViewCell {

    @IBOutlet weak var viewCln: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblSubject: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
