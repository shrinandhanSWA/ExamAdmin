

//
//  ViewController.swift
//  ExamPlanner2
//
//  Created by 19shrinandhanp on 6/29/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource

{

    @IBOutlet weak var btnSorting: UIButton!
    fileprivate var longPressGesture: UILongPressGestureRecognizer!
    @IBOutlet weak var lblColoumn: UILabel!
    
    @IBOutlet weak var CStepper: UIStepper!
    
    @IBOutlet weak var btnUpload: UIButton!
    
    var dataArray = NSMutableArray()
    @IBOutlet var clnView: UICollectionView!
    
    var numberofcoloumns : Double = 4.0
    
    var isFromSorting : Bool = false
    
    @IBOutlet weak var viewWelcome: UIView!
    @IBOutlet weak var btnShare: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        if  GVUserDefaults.standard()?.userId == nil {
            let strUserId : String = UUID().uuidString
            print(strUserId)
            GVUserDefaults.standard()?.userId = strUserId as NSString
        }
        
     
        
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
        clnView.addGestureRecognizer(longPressGesture)
        
        self.CStepper.value = numberofcoloumns
     lblColoumn.text = Int(self.CStepper.value).description
        clnView.dataSource = self
        clnView.delegate = self
       
        clnView.register(UINib(nibName: "examCell", bundle: nil), forCellWithReuseIdentifier: "examCell")

     
        clnView.reloadData()
        
        self.CStepper.addTarget(self, action:#selector(CStepperAction(_:)), for: .valueChanged)
        
        self.btnSorting.addTarget(self, action: #selector(onClickSorting), for: .touchUpInside)
        
        self.btnShare.addTarget(self, action: #selector(onClickShare), for: .touchUpInside)
        
        self.btnUpload.addTarget(self, action: #selector(onClickUpload), for: .touchUpInside)
        
       
        
         self.viewWelcome.isHidden = true
        
          NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
        
    }
    @objc func handleLongGesture(gesture: UILongPressGestureRecognizer) {
        switch(gesture.state) {
            
        case .began:
            guard let selectedIndexPath = clnView.indexPathForItem(at: gesture.location(in: clnView)) else {
                break
            }
            clnView.beginInteractiveMovementForItem(at: selectedIndexPath)
        case .changed:
            clnView.updateInteractiveMovementTargetPosition(gesture.location(in: gesture.view!))
        case .ended:
            clnView.endInteractiveMovement()
        default:
            clnView.cancelInteractiveMovement()
        }
    }
    @objc func CStepperAction(_ sender: UIStepper)
    {
        lblColoumn.text = Int(sender.value).description
        numberofcoloumns = sender.value
        clnView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "Seating Plan"
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = UIColor.init(forColorString:"0096FF")
        self.navigationController?.navigationBar.isOpaque = false
        self.navigationController?.navigationBar.isTranslucent = false
        
    
        let btnUpload = UIBarButtonItem(title: "Upload Here", style: .plain, target: self, action: #selector(onClickUpload))
        self.navigationItem.rightBarButtonItem = btnUpload
        
        SVProgressHUD.show()
        self.APIManager()

    }
    @objc func onClickUpload()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "HowtoUploadCsvViewController") as! HowtoUploadCsvViewController
        self.navigationController?.pushViewController(vc, animated: true)
      
    }
    
    @objc func onClickShare ()
    {
        var seatId : String = ""
        
      for i in dataArray
      {
        let dictData = i as! NSDictionary
        
        if seatId.isEmpty
        {
            seatId = String(format: "%@", dictData.object(forKey: "studentid") as! CVarArg)
        }else
        {
            let seatNo : String = String(format: "%@", dictData.object(forKey: "studentid") as! CVarArg)
            seatId += String(format: ",%@",seatNo)
        }
    
      }
        print(seatId)
        //studentid = 2;
        //http://localhost/api/generate_pdf.php?q
        //http://php3.shaligraminfotech.com/esp/generate_pdf.php?q=6,7,10,2,1,5,8,3,9,4
        if GVUserDefaults.standard()?.userId != nil
        {
            let strUserId : String = GVUserDefaults.standard()?.userId! as String? ?? ""
            let strName : String = String(format:"http://php3.shaligraminfotech.com/esp/generate_pdf.php?q=\(strUserId),\(seatId)")
            self.showShareActivity(msg:"\(strName) ", sourceRect: nil)
        
        }
    }
    @objc func onClickSorting(){
    
    let vc = self.storyboard?.instantiateViewController(withIdentifier: "SortingViewController") as! SortingViewController
   
    self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func dummydata() {
        
        
        var dictData = NSMutableDictionary()
        
        dictData.setValue("Nandhu", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
        dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Juan", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("SL", forKey:keyLevel)
        dictData.setValue("25/06/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
         dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
        dictData = NSMutableDictionary()
        dictData.setValue("Dino", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
         dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Aimee", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 2", forKey:keyComponent)
        dictData.setValue("SL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("LAPTOP", forKey:keySpecial)
         dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        dictData = NSMutableDictionary()
        dictData.setValue("Trina", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
         dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
        dictData = NSMutableDictionary()
        dictData.setValue("Trina123", forKey:keyName)
        dictData.setValue("Physics", forKey:keySubject)
        dictData.setValue("Paper 1", forKey:keyComponent)
        dictData.setValue("HL", forKey:keyLevel)
        dictData.setValue("25/07/2018", forKey:keyDate)
        dictData.setValue("NONE", forKey:keySpecial)
         dictData.setValue("1", forKey:"studentid")
        
        dataArray.add(dictData)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "examCell", for: indexPath) as! examCell
        cell.backgroundColor = UIColor.lightGray
        cell.viewCln.backgroundColor = UIColor.init(forColorString:"0096FF")
        let dictData : NSDictionary = dataArray[indexPath.item] as! NSDictionary
        
        cell.lblName.text = dictData.object(forKey: keyName) as? String
        cell.lblSubject.text = dictData.object(forKey: keySubject) as? String
        
        
        cell.lblName.font = UIFont.getFont(custFontName: custFont_Robot_Medium
            , ofSize: 13)
        cell.lblSubject.font = UIFont.getFont(custFontName: custFont_Robot_Medium
            , ofSize: 13)

        return cell
            }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let dictData : NSMutableDictionary = NSMutableDictionary.init(dictionary: dataArray[indexPath.item] as! NSDictionary)
       // let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "StudentDetailsViewController") as! StudentDetailsViewController
        vc.dictStudentData = dictData
       self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return true
    } //http://localhost/api/product/read.php//
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        print("Starting Index: \(sourceIndexPath.item)")
        print("Ending Index: \(destinationIndexPath.item)")
        
        let dictData : NSDictionary = dataArray[sourceIndexPath.item] as! NSDictionary
        let dictDataDestination : NSDictionary = dataArray[destinationIndexPath.item] as! NSDictionary
        
        dataArray.replaceObject(at: destinationIndexPath.item, with: dictData)
        dataArray.replaceObject(at: sourceIndexPath.item, with: dictDataDestination)
        
        clnView.reloadData()
    }//
  

  func  APIManager()
   {
     self.dataArray.removeAllObjects()
    
    if GVUserDefaults.standard()?.userId != nil
    {
        let strUserId : String = GVUserDefaults.standard()?.userId! as String? ?? ""
        
        let urlString  : String = "http://php3.shaligraminfotech.com/esp/product/read.php?q=\(strUserId)"
        
        guard let url = URL(string: urlString) else {
            print("Error: cannot create URL")
            return
        }
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /todos/1")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                }
                return
            }
            // parse the result as JSON, since that's what the API provides
            do {
                guard let todo = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? NSDictionary else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The todo is: " + todo.description)
                
                if todo.object(forKey: "records") == nil
                {
                    DispatchQueue.main.async {
                    self.viewWelcome.isHidden = false
                    }
                }else
                {
                    
                    if self.isFromSorting == true
                    {
                        
                        if APP_DELEGATE.saveDataArray != nil
                        {
                            self.dataArray.addObjects(from: APP_DELEGATE.saveDataArray as! [Any])
    self.isFromSorting = false
                        }
                    }else
                    {
                        let dictDataArray =  todo.object(forKey: "records") as? NSArray
                        self.dataArray.addObjects(from: dictDataArray as! [Any])
                        DispatchQueue.main.async {
                            self.viewWelcome.isHidden = true
                        }
                    }
                    
                    
                }
                
              
                
                DispatchQueue.main.async {
                    self.clnView.reloadData()
                    SVProgressHUD.dismiss()
                }
                
                
            } catch  {
                print("error trying to convert data to JSON")
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                }
                return
            }
        }
        
        task.resume()
        
    }
    }
    
}
extension ViewController{
   
    
    @objc func methodOfReceivedNotification(notification: Notification)
    {
        self.isFromSorting = true
    }
}
extension ViewController: UICollectionViewDelegateFlowLayout {
    
    internal func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellsAcross: CGFloat = CGFloat(numberofcoloumns)
        var widthRemainingForCellContent = collectionView.bounds.width
        if let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout {
            let borderSize: CGFloat = flowLayout.sectionInset.left + flowLayout.sectionInset.right
            widthRemainingForCellContent -= borderSize + ((cellsAcross - 1) * flowLayout.minimumInteritemSpacing)
        }
        let cellWidth = widthRemainingForCellContent / cellsAcross
        return CGSize(width: cellWidth, height: cellWidth)
    }
    
    internal func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.2) {
            if let cell = collectionView.cellForItem(at: indexPath) as? examCell {
                cell.viewCln.transform = .init(scaleX: 0.70, y: 0.70)
                cell.contentView.backgroundColor = UIColor.lightGray
            }
        }
    }
    
    internal func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.2) {
            if let cell = collectionView.cellForItem(at: indexPath) as? examCell {
                cell.viewCln.transform = .identity
                cell.contentView.backgroundColor = .white
            }
        }
    }
    
}
extension ViewController
{
    
    func topViewController()-> UIViewController{
        var topViewController:UIViewController = UIApplication.shared.keyWindow!.rootViewController!
        
        while ((topViewController.presentedViewController) != nil) {
            topViewController = topViewController.presentedViewController!;
        }
        
        return topViewController
    }
    
    func showShareActivity(msg:String?, sourceRect:CGRect?){
        var objectsToShare = [AnyObject]()
        
        if let msg = msg {
            objectsToShare = [msg as AnyObject]
        }
        
        let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        activityVC.modalPresentationStyle = .popover
        activityVC.popoverPresentationController?.sourceView = topViewController().view
        if let sourceRect = sourceRect {
            activityVC.popoverPresentationController?.sourceRect = sourceRect
        }
        
        topViewController().present(activityVC, animated: true, completion: nil)
    }
}
