//
//  CheckCSVViewController.swift
//  ExamPlanner2
//
//  Created by HITESH BALDANIYA on 19/10/18.
//  Copyright © 2018 19shrinandhanp. All rights reserved.
//

import UIKit
import WebKit

class CheckCSVViewController: UIViewController,WKNavigationDelegate{

    var webView : WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let filePath = Bundle.main.url(forResource: "SampleData", withExtension: "csv")

        webView = WKWebView(frame:CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height - 64))
        webView.navigationDelegate = self

        let requestCSV = URLRequest(url: filePath!)
        webView.load(requestCSV)

        self.view.addSubview(webView)
       
    }

    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "CSV Format"
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = UIColor.init(forColorString:"0096FF")
        self.navigationController?.navigationBar.isOpaque = false
        self.navigationController?.navigationBar.isTranslucent = false
        
        let btnback =  UIBarButtonItem(image:UIImage.init(named: "back"), style:  .plain, target: self, action: #selector(onClickBack))
        self.navigationItem.leftBarButtonItem = btnback
        
    }
    
    @objc func onClickBack()
    {
        self.dismiss(animated: true, completion: nil)
        
    }
    
    //MARK:- WKNavigationDelegate
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
    }
    
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("Strat to load")
       
        DispatchQueue.main.async {
            
            SVProgressHUD.show()
        }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("finish to load")
        DispatchQueue.main.async {
            
            SVProgressHUD.dismiss()
        }
        
    }
}
