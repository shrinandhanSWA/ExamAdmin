//
//  GVUserDefaults+Properties.m
//  KDAH
//
//  Created by Mihir Thakkar on 9/7/16.
//  Copyright © 2016 Elite InfoWorld. All rights reserved.
//

#import "GVUserDefaults+Properties.h"

@implementation GVUserDefaults (Properties)

@dynamic userId;

@end
