//
//  GVUserDefaults+Properties.h
//  KDAH
//
//  Created by Mihir Thakkar on 9/7/16.
//  Copyright © 2016 Elite InfoWorld. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GVUserDefaults.h"

@interface GVUserDefaults (Properties)
{
    
}

//@property (nonatomic, readwrite) BOOL isLogin;

@property (nonatomic, weak) NSString *userId;


@end
